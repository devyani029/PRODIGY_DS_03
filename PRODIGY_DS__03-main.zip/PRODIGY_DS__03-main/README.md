# PRODIGY_DS__03

TASK - 03 Build a decision tree classifier to predict whether a customer will purchase a product or service based on their demographic and behavioral data. Use a dataset such as the Bank Marketing dataset from the UCI Machine Learning Repository.

This repository contains a collection of visualizations based on a car details dataset. The visualizations and Decision Tree Algorithm explores trends, patterns, and insights related to predict whether a customer will purchase a product or service based on their past historical data.
